import React from 'react';
import classes from './CropSizes.css';
import CropSize from './CropSize/CropSize';
import Button from '../UI/Button/Button';

const cropSizes = props => {
    return (
        <form className={classes.CropSizesForm}>
            {props.cropSizes.map( (item, index) => {
                return <CropSize key={item.id} id={item.id} value={item.value} label={item.label} checked={item.checked} change={() => {props.sizeChange(item.id)}}/>
            })}
            <Button clicked={props.confirmSize}>Size Preview</Button>
        </form>
    )
}

export default cropSizes;