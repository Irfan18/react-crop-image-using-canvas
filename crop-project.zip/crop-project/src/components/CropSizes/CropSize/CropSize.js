import React from 'react';

const cropSize = props => (
    <div>
        <input id={"size" + props.id} type="radio" name="crop-size" value={props.value} onChange={props.change} checked={props.checked}/>
        <label htmlFor={"size" + props.id}>{props.label}</label>
    </div>
)

export default cropSize;