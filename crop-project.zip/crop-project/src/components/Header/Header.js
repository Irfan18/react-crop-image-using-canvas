import React from 'react';
import classes from './Header.css';

const header = props => (
    <div className={classes.Header}>
        <p className={classes.Name}>Image Crop</p>
        <p className={classes.Developer}>Developed by Irfan Shaikh</p>
    </div>
)

export default header;