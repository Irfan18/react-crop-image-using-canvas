import React from 'react';
import classes from './ValidationError.css';

const validationError = props => (
    <span className={classes.ValidationError}>{props.children}</span>
)

export default validationError;