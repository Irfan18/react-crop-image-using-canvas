import React from 'react';
import classes from './SectionHeading.css';

const sectionHeading = props => (
    <h2 style={props.style} className={classes.SectionHeading}>{props.children}</h2>
)

export default sectionHeading;