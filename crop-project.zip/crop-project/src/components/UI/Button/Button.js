import React from 'react';
import classes from './Button.css';
const Button = props => (
    <button onClick={props.clicked} style={props.style} className={classes.Button}>{props.children}</button>
)

export default Button;