import React from 'react';
import classes from './Note.css';

const note = props => (
    <span className={classes.Note}><em>{props.children}</em></span>
)

export default note;