import React from 'react';
import SectionHeading from '../UI/SectionHeading/SectionHeading';
import Note from '../Note/Note';
import ValidationError from '../UI/ValidationError/ValidationError';

import classes from './UploadImage.css';

const uploadImage = props => {
    let message = <Note>Upload image of size 1024*1024 px only</Note>;
    if(props.error) {
        message = <ValidationError>{props.error}</ValidationError>
    }
    return (
        <div className={classes.UploadImageWrapper}>
            <SectionHeading>Hi, select your image and upload here to crop</SectionHeading>
            <form className={classes.UploadImageForm}>
                <label className={classes.FileLabel}>
                    <input type="file" name="upload-file" className={classes.UploadFile} onChange={props.uploadImage} required/>
                    <span>Upload Image</span>
                </label>
                {message}
            </form>
        </div>
    )
}

export default uploadImage;