import React from 'react';
import Layout from './hoc/Layout/Layout';
import CropBuilder from './containers/CropBuilder/CropBuilder';

function App() {
  return (
    <div>
      <Layout>
        <CropBuilder />
      </Layout>
    </div>
  );
}

export default App;
