const Auxilliary = props => props.children;

export default Auxilliary;