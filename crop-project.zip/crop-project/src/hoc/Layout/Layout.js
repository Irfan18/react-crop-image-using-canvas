import React, { Component } from 'react';
import Header from '../../components/Header/Header';
import Auxilliary from '../Auxilliary/Auxilliary';

class Layout extends Component {
    state = {

    }

    render() {
        return (
            <Auxilliary>
                <Header />
                {this.props.children}
            </Auxilliary>
        )
    }
}

export default Layout;

