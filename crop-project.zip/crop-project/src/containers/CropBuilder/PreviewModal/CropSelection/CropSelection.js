import React, { Component } from 'react';
import Auxilliary from '../../../../hoc/Auxilliary/Auxilliary'
import classes from './CropSelection.css';
import Note from '../../../../components/Note/Note';
import Button from '../../../../components/UI/Button/Button';

class CropSelection extends Component {
    constructor(props) {
        super(props)
        this.state = {

        }
    }

    render() {
        return (
            <Auxilliary>
                <Note>Double click and hold on green frame to drag and select the area to crop</Note>
                <canvas className={classes.SelectionCanvas} ref={this.props.canvasRef} id="canvas" width="512" height="512"></canvas>
                <img ref={this.props.imageRef} className={classes.CropImageSelection} src={this.props.previewUrl} alt="Preview"></img>
                <div className={classes.ButtonWrap}>
                    <Button clicked={this.props.imageCrop}>Crop</Button>
                </div>
            </Auxilliary>
        )
    }
}

export default CropSelection;