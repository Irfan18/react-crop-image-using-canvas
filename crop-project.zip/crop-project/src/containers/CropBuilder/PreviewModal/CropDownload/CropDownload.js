import React, { Component } from 'react';
import Button from '../../../../components/UI/Button/Button';

import classes from './CropDownload.css'

class CropDownload extends Component {
    constructor(props) {
        super(props);

        this.canvasCropRef = React.createRef()
    }

    componentDidMount() {
        // canvas on which cropped image needs to be shown
        const cropCanvas = this.canvasCropRef.current;
        // context fro canvas
        const cropCtx = cropCanvas.getContext('2d');
        // create image
        const imageObj = new Image();
        // formula to convert crop image on 512px into 1024px image
        // sourceX and sourceY are the position of rect frame start
        // double the value of x and y along with cropWidth and cropHeight to convert back from 512px to 1024px
        // substract x and y from cropWidth and cropHeight to make x and y position at start of rect and add to cropWidth and cropHeight to crop image on 1024 x 1024 px image size
        const sourceX = ((this.props.valueX * 2) - (this.props.cropWidth * 2)) + this.props.cropWidth;
        const sourceY = ((this.props.valueY * 2) - (this.props.cropHeight * 2)) + this.props.cropHeight;
        // sourceWidth and sourceHeight are actual cropped width and height
        const sourceWidth = this.props.cropWidth * 2;
        const sourceHeight = this.props.cropHeight * 2;
        // same cropped width and height on canvas
        const destWidth = sourceWidth;
        const destHeight = sourceHeight;
        // position on canvas cropped image to be shown
        const destX = 0;
        const destY = 0;
        imageObj.onload = function() {
            // after image loads draw cropped portion of image on it using these units
            cropCtx.drawImage(imageObj, sourceX, sourceY, sourceWidth, sourceHeight, destX, destY, destWidth, destHeight);
        };
        imageObj.src = this.props.url;
    }

    // handle download event for when download gets clicked
    handleCropImageDownload = (event) => {
        event.preventDefault();
        const canvas = this.canvasCropRef.current;
        const link = document.createElement('a');
        link.download = 'cropped-' + this.props.cropWidth * 2 + 'x' + this.props.cropHeight * 2 + 'px.jpg';
        link.href = canvas.toDataURL();
        link.click();
    }

    render() {
        return (
            <div className={classes.CropDownload}>
                <p>Image Cropped Successfully</p>
                <canvas ref={this.canvasCropRef} width={this.props.cropWidth * 2} height={this.props.cropHeight * 2}></canvas>
                <div>
                    <Button clicked={this.handleCropImageDownload}>Download</Button>
                </div>
            </div>
        )
    }
}

export default CropDownload;