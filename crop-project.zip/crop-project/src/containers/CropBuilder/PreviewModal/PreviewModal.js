import React, { Component } from 'react';
import Modal from '../../../components/UI/Modal/Modal';
import CropDownload from './CropDownload/CropDownload';
import CropSelection from './CropSelection/CropSelection';

import classes from './PreviewModal.css';

let rectCanvas, rectCtx, dragok = false, x, y, cropWidth, cropHeight, width = 512, height = 512, imageCtx, img, timeInterval;
class PreviewModal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isCrop: false
        }
        // ref for canvas
        this.canvasRef = React.createRef();
        // ref for image
        this.canvasImageRef = React.createRef();
        
        this.draw = this.draw.bind(this);
    }

    shouldComponentUpdate(nextProps) {
        return nextProps.show;
    }

    componentDidMount() {
        // canvas to load image
        let imageCanvas = this.canvasRef.current;
        // context for image
        imageCtx = imageCanvas.getContext("2d");
        // ref for image
        img = this.canvasImageRef.current;
        // cropWidth and cropHeight to be used half coz we are going to use half of actual image size e.g 1024px will become 512px
        cropWidth = this.props.cropWidth/2;
        cropHeight = this.props.cropHeight/2;
        // initialize frame position on 512px image
        x = cropWidth;
        y = cropHeight;
        img.onload = () => {
            // load image on canvas
            imageCtx.drawImage(img, 0, 0, width, height);
            // initialize rect frame on canvas where image is loaded
            this.init();
            // when mouse clicks on rect frame
            rectCanvas.onmousedown = this.myDown;
            // when mouse drags or move on rect frame
            rectCanvas.onmousemove = this.myMove;
            // when mouse leave the rect frame
            rectCanvas.onmouseup = this.myUp;
        }
    }

    init() {
        // ref canvas on which image is loaded
        rectCanvas = this.canvasRef.current;
        // context for frame
        rectCtx = rectCanvas.getContext("2d");
        // time interval to draw rect on canvas, it helps to drag rect as it draw on every position changed
        // we can decrease the interval time to get smooth effect
        timeInterval = setInterval(this.draw, 50);
        return timeInterval;
    }

    clear() {
        // clear old rect to create new
        rectCtx.clearRect(0, 0, width, height);
    }

    // create react frame accordind to passed units
    rect(x,y,w,h) {
        rectCtx.beginPath();
        rectCtx.rect(x,y,w,h);
        rectCtx.closePath();
        rectCtx.stroke();
    }

    draw() {
        // cleared the interval in function such as mouse up where we dont drag rect frame and assign it as undefined
        if(typeof(timeInterval) !== 'undefined') { 
            // clear the rect on every 50ms and draw new on different position
            this.clear();
            // draw a new image
            imageCtx.drawImage(img, 0, 0, width, height);
            // create a frame with green border
            rectCtx.strokeStyle="green";
            // draw rect such that the center becomes x, y position by subtracting cropWidth/2
            this.rect(x - (cropWidth/2), y - (cropHeight/2), cropWidth, cropHeight);
        }
    }

    // mouse move event on rect frame which continue to draw new position every 50ms
    myMove(e) {
        if (dragok){
            // new x and y position is provided on move to draw
            x = e.offsetX;
            y = e.offsetY;
        }
    }
    
    // mouse down on rect frame
    myDown(e) {
        // condition to check if the mouse down event is done inside the frame
        if(e.offsetX < x + (cropWidth/2) && e.offsetX > x - (cropWidth/2) && e.offsetY < y + (cropHeight/2) && e.offsetY > y - (cropHeight/2)) {
            // new x, y position of the frame which pass to the draw function to change position
            x = e.offsetX;
            y = e.offsetY;
            // boolean as drag or move event can be done
            dragok = true;
        }
        // initialize interval as down event is done to change position of rect frame
        timeInterval = setInterval(this.draw, 50);
    }
    
    // mouse up event where mouse leave the rect frame
    myUp() {
        // drag should be stopped
        dragok = false;
        // interval should gets clear as there is no need to draw
        clearInterval(timeInterval);
        // interval needs to assigned undefined as it does not clear number
        timeInterval = undefined;
    }

    // crop button clicked set isCrop true and show the cropped view with download button
    handleImageCrop = () => {
        this.setState({
            isCrop: true
        })
    }

    render() {
        return (
            <Modal show={this.props.show} modalClosed={this.props.modalClose} headerText={"Selected size to Crop: " + this.props.sizeLabel}>
                <div className={classes.PreviewModal}>
                    {
                        !this.state.isCrop ? 
                            <CropSelection canvasRef={this.canvasRef} imageRef={this.canvasImageRef} previewUrl={this.props.previewUrl} imageCrop={this.handleImageCrop}/> 
                        :
                            <CropDownload valueX={x} valueY={y} url={this.props.previewUrl} cropWidth={cropWidth} cropHeight={cropHeight}/>
                    }
                </div> 
            </Modal>
           
        )
    }
}

export default PreviewModal