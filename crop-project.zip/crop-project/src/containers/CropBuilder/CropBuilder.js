import React, { Component } from 'react';
import UploadImage from '../../components/UploadImage/UploadImage';
import UploadedImagePreview from './UploadedImagePreview/UploadedImagePreview';

import classes from './CropBuilder.css';

let self;
class CropBuilder extends Component {
    constructor(props) {
        super(props)
        this.state = {
            imageUrl: null,
            error: null,
            imageLoad: false
        }
        self = this;
    }

    handleImageUpload = (event) => {
        let url, img, error = null, 
        files = event.target.files;
        if(files.length) {
            if(files[0].type.includes('image')) {
                url = URL.createObjectURL(files[0]);
                img = new Image();
                img.onload = function () {
                    if(this.width !== 1024 || this.height !== 1024) {
                        error = "Upload image of size 1024*1024 px";
                    }
                    self.setState({
                        imageUrl: url,
                        error: error,
                        imageLoad: true
                    })
                };
                img.src =url;
            } else {
                error = "Upload an image file";
            }
        }

        if(error || url) {
            this.setState({
                imageUrl: url,
                error: error
            });
        }
    }

    render() {
        let uploadedImage = null;
        if(this.state.imageUrl && !this.state.error && this.state.imageLoad) {
            uploadedImage = <UploadedImagePreview previewUrl={this.state.imageUrl} />;
        }
        return (
            <div className={classes.CropBuilder}>
                <UploadImage error={this.state.error} uploadImage={this.handleImageUpload} />
                {uploadedImage}
            </div>
        )
    }
}

export default CropBuilder;