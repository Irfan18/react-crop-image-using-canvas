import React, { Component } from 'react';
import UploadImage from '../../components/UploadImage/UploadImage';
import UploadedImagePreview from './UploadedImagePreview/UploadedImagePreview';

import classes from './CropBuilder.css';

class CropBuilder extends Component {
    state = {
        imageUrl: null,
        error: null
    }

    handleImageUpload = (event) => {
        let url, img, error = null, 
        files = event.target.files;
        if(files.length) {
            if(files[0].type.includes('image')) {
                img = new Image();
                img.onload = function () {
                    if(this.width !== 1024 && this.height !== 1024) {
                        error = "Upload image of size 1024*1024 px";
                    }
                };
                url = URL.createObjectURL(files[0]);
                img.src =url;
            } else {
                error = "Upload an image file";
            }
        }
        if(error || url) {
            this.setState({
                imageUrl: url,
                error: error
            })
        }
    }

    render() {
        let uploadedImage = null;
        if(this.state.imageUrl && !this.state.error) {
            uploadedImage = <UploadedImagePreview previewUrl={this.state.imageUrl} />;
        }
        return (
            <div className={classes.CropBuilder}>
                <UploadImage error={this.state.error} uploadImage={this.handleImageUpload} />
                {uploadedImage}
            </div>
        )
    }
}

export default CropBuilder;