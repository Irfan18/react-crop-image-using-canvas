import React, { Component } from 'react';
import SectionHeading from '../../../components/UI/SectionHeading/SectionHeading';
import CropSizes from '../../../components/CropSizes/CropSizes';
import Auxilliary from '../../../hoc/Auxilliary/Auxilliary';
import Note from '../../../components/Note/Note';

import PreviewModal from '../PreviewModal/PreviewModal';

import classes from './UploadedImagePreview.css'

class UploadedImagePreview extends Component {
    state = {
        cropSizes: [
            {
                id: 1,
                width: 755,
                height: 450,
                label: "755 x 450 px",
                value: "755x450",
                checked: true
            },
            {
                id: 2,
                width: 365,
                height: 450,
                label: "365 x 450 px",
                value: "365x450",
                checked: false
            },
            {
                id: 3,
                width: 365,
                height: 212,
                label: "365 x 212 px",
                value: "365x212",
                checked: false
            },
            {
                id: 4,
                width: 380,
                height: 380,
                label: "380 x 380 px",
                value: "380x380",
                checked: false
            }
        ],
        sizeSelected: false
    }

    handleSizeChangeInput = (id) => {
        let updateCropSizes = [...this.state.cropSizes]
        updateCropSizes.map( (item, index) => {
            if(item.id === id) {
                item.checked = true;
            } else {
                item.checked = false;
            }
            return item;
        });
        this.setState({
            cropSizes: updateCropSizes
        });
    }

    handleModalCloseEvent = _ => {
        this.setState({
            sizeSelected: false
        });
    }

    confirmSizeSelection = event => {
        event.preventDefault();
        this.setState({
            sizeSelected: true
        });
    }

    render() {
        let selectedCropSize = this.state.cropSizes.filter( size => {
            return size.checked === true;
        })[0];
        return (
            <Auxilliary>
                <div className={classes.UploadedImagePreview}>
                    <SectionHeading>Uploaded Image Preview</SectionHeading>
                    <div className={classes.PreviewDetails}>
                        <img className={classes.PreviewImage} src={this.props.previewUrl} alt="preview" />
                        <Note>Select a size and click on the size preview button</Note>
                        <CropSizes cropSizes={this.state.cropSizes} sizeChange={this.handleSizeChangeInput} confirmSize={this.confirmSizeSelection} />
                    </div>
                </div>
                { 
                    this.state.sizeSelected ? 
                        <PreviewModal modalClose={this.handleModalCloseEvent} show={this.state.sizeSelected} previewUrl={this.props.previewUrl} sizeLabel={selectedCropSize.label} cropWidth={selectedCropSize.width} cropHeight={selectedCropSize.height} size={selectedCropSize.value}></PreviewModal> 
                    :
                        null
                }
            </Auxilliary>
        )
    }
}

export default UploadedImagePreview;